# Changelog

## 0.5.0 — 2026-10-18

- `db.reconnect()` works from any state: it closes an open socket and connects again with `token` called afresh, so a sign-in over an open anonymous connection switches to the new token. Breaking: before, it did nothing unless the connection was `refused`.
- Sign-in over auth `session`: connect with no token (the `welcome` names `anonymous`), run the sign-in action, store the token from its result, `reconnect()`. The skill and the protocol reference say how.
- A 1008 close with `signed out` (the session ended, expired or was revoked) reads as `refused` with that error.
- `hello` sends `features: ["runs:1", "session:1"]`.
- Edits queued offline under one principal are never sent under another: when a `welcome` names someone else (a sign-out and sign-in on one page), each settles with an error and the outbox is emptied. People are told apart by `welcome.principal_id` (stable and unique), not the display name, so two people with one name never share edits; an older server without the id falls back to the name. `reconnect()` also cancels a pending backoff reconnect, so it opens one socket, not two.
- The saved outbox records which principal id made each edit. On the first `welcome` after a reload, saved edits from anyone else (or saved by an older client, unattributed) are dropped with a console warning and never sent. `Persisted.outbox` and `PersistChange.outbox` are now `OutboxEntry[]` (`{ item, principal }`); a custom `Storage` saves and returns them as given.
- An `invalidated` change (live or replayed) also re-reads the table's records held outside any open collection, not only its collections, so a change the server can't name per row still reaches them.
- A window's `items` stops at the last row once `lengthExact` is true. A 100-row window over a 22-row table now holds 22 items, not 22 and 78 `undefined` slots that never load (a list rendered `items` as an endless tail of placeholders).
- A sign-in page works with `instant` tables: while the `welcome` is `anonymous`, the client sends no table read (no `open_table`, no `open_records`); collections and records wait, loading, instead of failing with "sign in first", and load at the signed-in `welcome`.
- A write or run an access rule refused says what refused: the server's `code: "forbidden"` frames carry `table`, `rule` and `reason`, and the client puts them on `error.forbidden` (an `ActionError`, with `kind: "forbidden"`) and `run.error.forbidden`. The protocol types gain `AccessRefusal` and `RejectedFrame`; `AccessRefusal` is exported.
- The skill and protocol reference cover an API profile's own `sign_in:` list for anonymous sockets.
- MockServer fixtures take `principals` (token → the name `welcome` gives), `principalIds` (token → its `principal_id`) and `signIn` (a tokenless `hello` is anonymous, and its table reads and writes are refused).

## 0.4.4 — 2026-10-13

- A README for the npm page, plus `keywords` and `homepage`.

## 0.4.3 — 2026-10-13

- A run delivers to `on`/`useRunMessage` the messages sent while the connection was down or across a `resync`, from the server's `seq` on each message.

## 0.4.2 — 2026-10-13

- MockServer fixture `actions` also accept a project action's YAML key with dashes (`check-overdue` for `check_overdue`); naming one action both ways throws.
- Docs: fixture action keys are wire names, handlers are typed with `ActionHandler` and `MockRunControl`, and `run.start()` on a finished run begins a new run.
- Docs: rebuilding a list from `run.messages` after a reload, `start()` with no argument, and why `XFields` columns are nullable.

## 0.4.1 — 2026-10-13

- `db.reconnect()` connects again after `refused`, calling `token` afresh, for a sign-in form.
- The generated file's header says how it is regenerated: by the web dev container from `schema.json`, or with `npx vantage-client generate`.

## 0.4.0 — 2026-10-13

- Actions run as runs: `db.run.<action>` and `model.$run.<action>` give `start(args, { run? })`, `attach(id)` and `idle()`; a `Run` has reactive `status`, `state`, `result`, `error` and `messages`, plus `on`, `set` (inputs, optimistic), `cancel` and `done`. Breaking: `db.run.x(input)` is now `db.run.x.start(input)`.
- Row and toolbar action methods run the action and wait for its end; they no longer return the server's record.
- React: `useRun(factory, { key })` (re-attaches after a page reload), `useShared` and `useRunMessage`.
- `generate` emits `<Action>Run` (`args`, `state`, `inputs`, `messages`) per action and `$run` on models; the runtime schema carries each action's `state` and `messages`.
- `hello` sends `features: ["runs:1"]`; a server without it fails runs with a clear message. An unanswered `start` is sent again with the same id after a reconnect or `resync`, and running runs attach again; unknown frames, fields and statuses are ignored.
- `run.on`/`useRunMessage` take `vantage.notify` and `vantage.log`; `run.forget()` returns a run to `idle`; `useRun` keys are scoped to the action.
- Removed: `db.jobs`, `stopJob`, `useJobs`, the `Job` type and `ActionResult.job`.
- MockServer runs action handlers as runs (`(row, args, run)`), with `server.runs`.

## 0.3.0 — 2026-10-13

- Connects to `/v1/ws` on the page's origin by default; outside a browser a `url` is required.
- `hello` sends `protocol: 1` and the `token` option.
- `db.connection` is `{ status, halted, error? }`: `online`/`offline` became `open`/`closed`, plus final `refused` and `protocol_mismatch` (`halted`); `db.ready` settles on them and resolves with the connection. `useConnection()` returns `halted` too.
- `resync` reopens what is shown without flashing rows; refusals land on `error` and are not retried.
- `useRecord` returns `{ value, status, error }`; collections and windows carry `error`.
- Windows add `total`, `totalExact`, `settled`, `length`, `lengthExact` and `whenLoaded()`; collections and `useCollection` add `totalExact`.
- The same collection description gives the same object while it is in use.
- Removed: `filter`/`find`/`some`/`every` on collections, and the root exports `Reaction`, `track`, `untracked`, `WebSocketTransport`, `defaultUrl`, `PROTOCOL`, `uuidv7` and `DraftFields`. `Vantage` is exported as a type only, and internal members are left out of the published types.
- `observer` keeps a generic component's type.
- MockServer adds `opened` and `refuseWrites`/`allowWrites`.
- Edits queued while offline are sent on reconnect in the same page only; a reload loses them.
- Draft members are `$`-prefixed (`$flash`, `$isDirty`, `$status`, `$errors`, `$dirty`, `$revert`); columns, references and row actions with reserved names are refused.
- `npx vantage-client generate --from <url | file>` replaces the Rust `generate-ts`; it reads the running server's `/v1/schema` directly.
- Development runs on local Node 22+; no Docker.
- The generated `schema` carries `sortable`, `filter`, `defaultSort` (`{ column, direction }`) and each enum column's values; labels in generated comments are escaped.
- Ships an ESM build with types, the `generate` CLI, and the `vantage-client` skill.
