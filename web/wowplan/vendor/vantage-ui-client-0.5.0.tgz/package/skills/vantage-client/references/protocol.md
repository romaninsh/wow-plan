# The wire protocol

JSON text frames over `ws(s)://<host>/v1/ws`, tagged by `t`. Requests carry
an `id`; replies echo it. The client handles all of this; read on for raw
scripts and debugging. HTTP: `/v1/schema` (the schema `generate` reads),
`/v1/health`, `/v1/ready` (503 naming entities whose datasource is down).

## Session

| Client → server | Server → client |
|---|---|
| `hello {protocol: 1, token?, cursor?, schema_hash?, features?}` | `welcome {protocol, principal, principal_id, anonymous, epoch, seq, schema_hash, resync, features}`: `principal` is the name to show, `principal_id` the stable id that tells people apart (`identity:<id>`, `anonymous:<socket>`, `token:<name>`), `anonymous` true for a socket not signed in (the client then opens no table, `instant` ones included, until a signed-in `welcome`); the features both sides have (`runs:1`, `session:1`). Under auth `session` a `hello` without a token is welcomed as `anonymous`, which may only `invoke` the actions the project lists in `session.signed_out` (sign in), `run_set`, `run_cancel` and `ping`; anything else gets `error {kind: "forbidden", message: "sign in first"}` |
| a frame with a `t` the server doesn't know | `error {code: "unknown_frame"}`; a client ignores frames and fields it doesn't know |
| | `error {kind, message, code: "protocol"}`, then close 1002: another protocol version |
| | `error {kind: "forbidden", message}`: the token is refused; the socket stays open for another `hello` |
| | `resync {epoch, seq, schema_hash}`: the API was reloaded; reopen what you show, and re-attach the runs you follow (`invoke {run}`): an `invoke` answered around the reload may not stream its run |
| | `reload`: the served frontend was rebuilt; reload the page (sent before `welcome` too) |
| | close 1008: after a reload, the API refuses the token; or `signed out`: the session ended (signed out, expired, deleted, its person deactivated) |
| | `resync` also follows a change to the session's own fields (impersonation): the same `hello` holds, collections and interest are gone |
| | close 1012 `reconnect`: the server is shutting down |

Nothing but `hello` is accepted before a `welcome`.

## Reading

| Client → server | Server → client |
|---|---|
| `open_table {table, where?, search?, sort?, via?, limit?}` | `rows {sub, start, ids, records, total, complete, seq}` |
| `viewport {sub, start, count}` | `members {sub, start, ids, records, total, complete}` |
| `close {sub}` | `members` pushed when membership or order changes |
| `open_records {table, ids}` | `records {records, missing}` |
| `interest {remove: [[table, id]]}` | `changed {seq, events: upsert \| removed \| invalidated}` |

`where` is a list of `[column, op, value]` tuples, `sort` is
`[column, "asc" | "desc"]`, and `via` is `{table, id, ref}` (a parent's
has-many). A refused request gets `error {id, kind, message}`.

## Writing and actions

| Client → server | Server → client |
|---|---|
| `flash {table, rid?, patch}` · `batch {items}` · `delete {table, rid}` | `flashed {rid, seq, record}` · `rejected {message, field_errors, code?, table?, rule?, reason?}` · `batch_result {results}` |
| `invoke {run, action?, rid?, args}` (no `action`: attach) | `result {run, status: started \| attached \| done}`, then `run {run, seq, status?, state?, messages?, result?, error?}`, the first a snapshot |
| `run_set {run, name, value}` · `run_cancel {run}` | `ack` · `error {kind, message, code}` |
| `options {action, field, form?}` | `options_result {items}` |

A run's `seq` counts its frames; a gap means one was missed, and an
`invoke {run}` brings a fresh snapshot. Each message is
`{name, payload, seq}`, `seq` being the frame it first went out in, so the
snapshot's messages past the last `seq` you applied are the ones you
missed. A refused `invoke` carries `code`:
`conflict` (the id was used with other args), `expired`, `forbidden` (no
such run for you, or an action the API can't run), `invalid` or `limit`.

A request an access rule refused carries `code: "forbidden"` and the
refusal beside `message`: `table` (the table's catalog key), `rule`
(`<datasource>.invariants.<column>`, `.script` for a rule script's,
`session.table`, `session.identity`) and `reason`, the rule's own words.
This holds for `rejected`, for `error` (an `open_table`, `open_records`,
`options` or `invoke` the rule refused) and for a run's `error` when a rule
stopped its body. Signed out, an `invoke` runs only the actions in the
API profile's `sign_in:` list, or without one `session.signed_out`.

## A raw script

```ts
// test: protocol#raw-script
const ws = new WebSocket("ws://127.0.0.1:8090/v1/ws");
ws.onopen = () => {
  ws.send(JSON.stringify({ t: "hello", id: 1, protocol: 1, token: process.env.VANTAGE_TOKEN }));
  ws.send(JSON.stringify({ t: "open_table", id: 2, table: "issues", where: [["status", "eq", "open"]], sort: ["created_at", "desc"], limit: 50 }));
};
ws.onmessage = (message) => console.log(JSON.parse(String(message.data)));
```

A WebSocket from a page on another origin is refused (403): `Origin` must
name the host the request was sent to. Scripts send no `Origin`.
