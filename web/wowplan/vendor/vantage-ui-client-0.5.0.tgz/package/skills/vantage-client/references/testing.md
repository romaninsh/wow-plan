# Testing

`@vantage-ui/client/testing` has `MockServer`: an in-memory vantage-server
that speaks the same frames, with no network. Collections filter, sort,
window and follow `via` like the real one; writes broadcast `changed` and
move collection membership. Use it in unit tests and Storybook.

## With the generated schema

```ts
// test: testing#generated
import { createTestVantage } from "@vantage-ui/client/testing";
import { schema, type Schema } from "./vantage.gen";

const { db, server } = createTestVantage<Schema>(schema, {
  tables: { issues: [{ id: "JIR-1", title: "Login fails", status: "open", project: "JIR" }] },
  actions: { "issues.close_issue": () => ({ status: "done" }) },
});
await db.ready;
const issue = await db.issues.ref("JIR-1").load();
server.upsert("issues", { id: "JIR-1", title: "Login fails on Safari" }); // someone else's edit
```

Fixtures also take `available` (which row actions a record offers, standing
in for `when:`), `validate` (refuse writes with a message or field errors),
`protocol` (the version the mock speaks) and `refuseHello` (refuse every
token with a message).

A third argument passes client options, such as `{ token: "test" }`.

## Runs

An action's handler is its body: `(row, args, run)`. Its return value (or
what its promise resolves to) is the run's `result`, and a row action's
returned object is applied to the row. `run` stands in for the body's run
vocabulary: `run.set(name, value)` sends a state patch, `run.wait(name)`
resolves once an input is set, `run.emit(name, payload)` and
`run.notify(text)` send messages. `server.runs` holds every run by id, with
its `action`, `args`, `state` and `status`:

```ts
// test: testing#runs
// continues from "With the generated schema": createTestVantage, schema, Schema
import { expect } from "vitest";

const triage = createTestVantage<Schema>(schema, {
  actions: {
    triage: async (_, args, run) => {
      run.set("total", 1);
      await run.wait("confirmed");
      run.emit("flagged", { issue: "JIR-1" });
      return `triaged ${args.project}`;
    },
  },
});
await triage.db.ready;
const run = triage.db.run.triage.start({ project: "JIR" });
await run.set("confirmed", true);
expect(await run.done).toEqual({ ok: true, value: "triaged JIR" });
expect(triage.server.runs.get(run.id)?.args).toEqual({ project: "JIR" });
```

Fixture `actions` are keyed by the action's wire name, the name `db.run`
uses: a project action's key with dashes turned into underscores
(`check_overdue` for `action/check-overdue.yaml`), and `<entity>.<name>`
for a row action. The YAML key with dashes (`"check-overdue"`) works too;
naming one action both ways throws. Type a handler declared on its own
with `ActionHandler`, and its `run` parameter with `MockRunControl`:

```ts
// test: testing#action-names
// continues from "With the generated schema": createTestVantage, schema, Schema
import { type ActionHandler, type MockRunControl } from "@vantage-ui/client/testing";
import { expect } from "vitest";

const checkOverdue: ActionHandler = async (_, __, run: MockRunControl) => {
  run.set("overdue", 3);
  return "3 tools are overdue";
};
const desk = createTestVantage<Schema>(schema, { actions: { check_overdue: checkOverdue } });
await desk.db.ready;
const run = desk.db.run.check_overdue.start({});
expect(await run.done).toEqual({ ok: true, value: "3 tools are overdue" });
expect(run.state.overdue).toBe(3);
```

`server.refuse("run_set", message)` refuses input writes, so a test can
check the rollback; `run_set` of a non-input or a wrong type is refused as
the real server does. `run.update({ a, b })` sends several variables in one
patch, as the server's throttle does. The fixture `eager: true` starts a
handler before the invoking socket follows the run, as vantage-server does,
so what it sends first arrives inside the first snapshot; `features: []`
is a server without runs.

## Without generated types

`MockServer.withTable` builds a one-entity schema from the rows' keys.
`db.table(name)` reaches any entity by name:

```ts
// test: testing#one-table
import { MockServer, createTestVantage } from "@vantage-ui/client/testing";

const server = MockServer.withTable("issues", [{ id: "1", title: "First" }]);
const { db } = createTestVantage(server, { token: "test" });
const all = await db.table("issues").all.load();
```

## Refusals, held replies and resync

The server-side events a test can cause:
- `server.refuse(op, message)` answers every `op` frame (`open_table`,
  `open_records`, `viewport`, …) with that error; `server.allow(op)` stops it;
- `server.refuseWrites(message)` refuses every write, whether the client
  sends it alone or batched with others; `server.allowWrites()` stops it;
- `server.hold(op)` keeps `op` replies pending until `server.release(op)`;
- `server.resync()` is an API reload: a new journal, every collection gone,
  `resync` sent to every client;
- `server.reload()` sends `reload` to every client, which calls its
  `onReload`;
- `server.invalidate(table)` is a coarse change: clients re-read the table;
- `server.opened` lists every collection a client opened (table, `where`,
  `sort`, …), refused ones too; `server.count(op)` counts the frames
  received, and `server.hellos` keeps every `hello`.

Assert on what the page asked for through these, not by spying on the
transport's frames:

```ts
// test: testing#opened
// continues from "Without generated types": server, db
import { expect } from "vitest";

await db.table("issues").where({ title: "First" }).load();
expect(server.opened.at(-1)).toEqual({ table: "issues", where: [["title", "eq", "First"]] });
server.refuseWrites("issues: column `title` is not writable");
const issue = await db.table("issues").ref("1").load();
const saved = await issue!.patch({ title: "Renamed" });
expect(saved.ok).toBe(false);
```

```ts
// test: testing#refusal
// continues from the previous block: server, db
import { expect } from "vitest";

server.refuse("open_table", "invalid column `x` is not filterable");
const refused = await db.table("issues").where({ x: 1 }).load();
expect(refused.error).toBe("invalid column `x` is not filterable");
expect(server.count("open_table")).toBe(1); // a refusal is not retried
```

```ts
// test: testing#resync
// continues from "Without generated types": server, db
import { expect } from "vitest";

const rows = () => db.table("issues").all.map((r) => r.title);
const settle = () => new Promise((resolve) => setTimeout(resolve, 5));
await db.table("issues").all.load();
server.setRows("issues", [{ id: "1", title: "First, renamed" }]); // the reloaded API's data

server.hold("open_table"); // keep the reopen pending
server.resync();
await settle();
expect(rows()).toEqual(["First"]); // still shown, no flash to empty
server.release("open_table");
await settle();
expect(rows()).toEqual(["First, renamed"]);
```

`transport.drop()` (from `createTestVantage`'s result) simulates a lost
connection; `transport.drop(1008, reason)` a refused one.
